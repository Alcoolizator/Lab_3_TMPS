from character.mage import Mage
from character.warrior import Warrior
from factory.level_factory import LevelFactoryCreator
from builder.map_director import MapDirector
from builder.map_builder import MapBuilder
from singleton.game_manager import GameManager

def main():
    # Facade pattern
    game_manager = GameManager.get_instance()

    # Adapter pattern
    mage = Mage("Gandalf")
    warrior = Warrior("Aragorn")

    # Decorator pattern
    level_factory_creator = LevelFactoryCreator()
    easy_level_factory = level_factory_creator.create_factory("easy")
    medium_level_factory = level_factory_creator.create_factory("medium")
    hard_level_factory = level_factory_creator.create_factory("hard")

    easy_level = easy_level_factory.create_level("Hobbiton")
    medium_level = medium_level_factory.create_level("Moria")
    hard_level = hard_level_factory.create_level("Mount Doom")

    # Composite pattern
    map_builder = MapBuilder()
    map_director = MapDirector(map_builder)
    map_data = [
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
    ]
    map_director.construct(map_data)
    game_map = map_director.get_map()

    # Flyweight pattern
    for row in game_map.rows:
        for cell in row.cells:
            cell.set_background_color("green")

    print("Welcome to the game!")
    print(f"Your game map:\n{game_map.draw()}")
    print("Choose a level to play:\n1. Easy\n2. Medium\n3. Hard")
    level_choice = int(input("Enter your choice (1, 2, or 3): "))

    if level_choice == 1:
        game_manager.play_game(easy_level)
    elif level_choice == 2:
        game_manager.play_game(medium_level)
    elif level_choice == 3:
        game_manager.play_game(hard_level)
    else:
        print("Invalid choice. Game over.")
