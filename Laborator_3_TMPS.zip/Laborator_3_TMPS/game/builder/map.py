class Map:
    def __init__(self):
        self.rows = []

    def add_row(self, row):
        self.rows.append(row)

    def draw(self):
        for row in self.rows:
            row.draw()
