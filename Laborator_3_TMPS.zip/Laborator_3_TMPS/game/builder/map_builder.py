from abc import ABC, abstractmethod
from typing import List
from builder.map import Map, MapRow
from .map import Map, MapRow



class MapBuilder(ABC):
    @abstractmethod
    def reset(self):
        pass

    @abstractmethod
    def set_size(self, size: int):
        pass

    @abstractmethod
    def set_start_position(self, x: int, y: int):
        pass

    @abstractmethod
    def set_finish_position(self, x: int, y: int):
        pass

    @abstractmethod
    def add_obstacle(self, x: int, y: int):
        pass

    @abstractmethod
    def get_map(self) -> Map:
        pass

class EasyMapBuilder(MapBuilder):
    def __init__(self):
        self.reset()

    def reset(self):
        self._map = Map()
        self._map.set_size(5)

        for i in range(5):
            row = MapRow()
            for j in range(5):
                row.add_cell("_")
            self._map.add_row(row)

    def set_size(self, size: int):
        pass

    def set_start_position(self, x: int, y: int):
        self._map.set_start_position(x, y)

    def set_finish_position(self, x: int, y: int):
        self._map.set_finish_position(x, y)

    def add_obstacle(self, x: int, y: int):
        self._map.get_row(y).set_cell(x, "x")

    def get_map(self) -> Map:
        return self._map

class MediumMapBuilder(MapBuilder):
    def __init__(self):
        self.reset()

    def reset(self):
        self._map = Map()
        self._map.set_size(10)

        for i in range(10):
            row = MapRow()
            for j in range(10):
                row.add_cell("_")
            self._map.add_row(row)

    def set_size(self, size: int):
        pass

    def set_start_position(self, x: int, y: int):
        self._map.set_start_position(x, y)

    def set_finish_position(self, x: int, y: int):
        self._map.set_finish_position(x, y)

    def add_obstacle(self, x: int, y: int):
        self._map.get_row(y).set_cell(x, "x")

    def get_map(self) -> Map:
        return self._map

class HardMapBuilder(MapBuilder):
    def __init__(self):
        self.reset()

    def reset(self):
        self._map = Map()
        self._map.set_size(15)

        for i in range(15):
            row = MapRow()
            for j in range(15):
                row.add_cell("_")
            self._map.add_row(row)

    def set_size(self, size: int):
        pass

    def set_start_position(self, x: int, y: int):
        self._map.set_start_position(x, y)

    def set_finish_position(self, x: int, y: int):
        self._map.set_finish_position(x, y)

    def add_obstacle(self, x: int, y: int):
        self._map.get_row(y).set_cell(x, "x")

    def get_map(self) -> Map:
        return self._map
