from .map_builder import MapBuilder

class MapDirector:
    def __init__(self, builder):
        self.builder = builder

    def construct(self, map_data):
        for row_data in map_data:
            self.builder.add_row(row_data)

    def get_map(self):
        return self.builder.get_map()
