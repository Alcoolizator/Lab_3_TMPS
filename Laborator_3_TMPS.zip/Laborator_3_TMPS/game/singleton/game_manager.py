class GameManager:
    __instance = None

    @staticmethod
    def get_instance():
        if GameManager.__instance is None:
            GameManager()
        return GameManager.__instance

    def __init__(self):
        if GameManager.__instance is not None:
            raise Exception("Singleton class, cannot instantiate more than once")
        else:
            GameManager.__instance = self

    def play_game(self, level):
        level.play()
