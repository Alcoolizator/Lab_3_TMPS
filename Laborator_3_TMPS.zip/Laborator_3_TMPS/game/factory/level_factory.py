from abc import ABC, abstractmethod
from .level import Level, EasyLevel, MediumLevel, HardLevel

class LevelFactory:
    @staticmethod
    def create_level(difficulty, location):
        if difficulty == "easy":
            return EasyLevel(location)
        elif difficulty == "medium":
            return MediumLevel(location)
        elif difficulty == "hard":
            return HardLevel(location)
        else:
            raise ValueError("Invalid difficulty level")

class LevelFactoryCreator(ABC):
    @abstractmethod
    def create_factory(self):
        pass

class EasyLevelFactoryCreator(LevelFactoryCreator):
    def create_factory(self):
        return LevelFactory.create_level("easy", "Forest")

class MediumLevelFactoryCreator(LevelFactoryCreator):
    def create_factory(self):
        return LevelFactory.create_level("medium", "Desert")

class HardLevelFactoryCreator(LevelFactoryCreator):
    def create_factory(self):
        return LevelFactory.create_level("hard", "City")
