from .level import Level

class MediumLevel(Level):
    def play(self):
        print("Playing medium level: {}".format(self.name))