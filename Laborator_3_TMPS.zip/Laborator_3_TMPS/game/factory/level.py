from abc import ABC, abstractmethod

class Level(ABC):
    def __init__(self, location):
        self.location = location

    def play(self):
        self.initialize()
        self.start()
        self.end()

    @abstractmethod
    def initialize(self):
        pass

    @abstractmethod
    def start(self):
        pass

    @abstractmethod
    def end(self):
        pass

class EasyLevel(Level):
    def initialize(self):
        print(f"Initializing Easy level at {self.location}...")

    def start(self):
        print("Starting Easy level...")

    def end(self):
        print("Ending Easy level.")

class MediumLevel(Level):
    def initialize(self):
        print(f"Initializing Medium level at {self.location}...")

    def start(self):
        print("Starting Medium level...")

    def end(self):
        print("Ending Medium level.")

class HardLevel(Level):
    def initialize(self):
        print(f"Initializing Hard level at {self.location}...")

    def start(self):
        print("Starting Hard level...")

    def end(self):
        print("Ending Hard level.")
