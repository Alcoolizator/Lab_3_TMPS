from .level import Level

class HardLevel(Level):
    def play(self):
        print("Playing hard level: {}".format(self.name))