from .level import Level

class EasyLevel(Level):
    def play(self):
        print("Playing easy level: {}".format(self.name))