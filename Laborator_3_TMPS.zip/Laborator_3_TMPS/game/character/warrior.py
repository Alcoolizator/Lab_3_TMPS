from .character import Character

class Warrior(Character):
    def attack(self):
        print("{} attacks with sword!".format(self.name))