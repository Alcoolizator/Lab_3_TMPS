from .character import Character

class Mage(Character):
    def attack(self):
        print("{} casts fireball!".format(self.name))