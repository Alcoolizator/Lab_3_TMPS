class Character:
    def __init__(self, name):
        self.name = name

    def attack(self):
        pass
